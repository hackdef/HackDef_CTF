<?php

final class Usuario
{
    private $datosUsuario;

    public function __construct($loginAttempt)
    {
        $this->datosUsuario = unserialize($loginAttempt);
        if (!$this->datosUsuario)
            throw new InvalidArgumentException('¿Que haces?');
    }

    private function sqlInjectionValidator(){
        if(str_contains($this->datosUsuario->username, "'"))
            return false;
        elseif (str_contains($this->datosUsuario->username, "\\"))
            return false;
        elseif (str_contains($this->datosUsuario->username, "\""))
            return false;
        return true;

    }

    private function validarNombre()
    {
        return $this->datosUsuario->username === '3lGr4nF0RjadOr';
    }

    private function validarPass()
    {
        return password_verify($this->datosUsuario->password, '$2y$07$BCryptRequires22Chrcte/VlQH0piJtjXl.0t1XkA8pw9dMXTpOq');
    }

    public function verificarLogin()
    {
        if (!$this->sqlInjectionValidator())
            throw new InvalidArgumentException('SQL ERROR: syntax error at or near');

        if (!$this->validarNombre())
            throw new InvalidArgumentException('Nombre de usuario incorrecto');

        if (!$this->validarPass())
            throw new InvalidArgumentException('Contraseña Incorrecta');

        return true;
    }

}
