<?php
include 'Configuration.php';
final class Token
{
    private $datosToken;

    public function __construct($mfaVerification)
    {
        $this->datosToken = unserialize($mfaVerification);
        if (!$this->datosToken)
            throw new InvalidArgumentException('¿Qué haces?');
    }

    private function validarNumHacker()
    {
        $num = Configuration::getNumEmpleado();
        return $num == $this->datosToken->numero;
    }

    private function validarToken()
    {
        $this->datosToken->_tokenCorrecto = random_int(1e10, 1e11 - 1);
        return (int)$this->datosToken->token === $this->datosToken->_tokenCorrecto;
    }

    public function verificarMFA()
    {
        if (!$this->validarNumHacker())
            throw new InvalidArgumentException('¿Qué no tienes el número o qué?');

        if (!$this->validarToken())
            throw new InvalidArgumentException('¿Qué no tienes el token o qué?');

        return true;
    }

}
