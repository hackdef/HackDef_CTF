<?php

class Configuration{
    public static function getNumEmpleado()
    {
        return "81712";
    }
}

