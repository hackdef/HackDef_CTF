<?php
include 'class/Usuario.php';

$notification = "";
session_start();

//Por Get es mas facil mi GFE
if (!empty($_GET) && isset($_GET['usuario'])) {
    $notification = new stdClass();
    try
    {
        //Datos del usuario
        $user = new Usuario(base64_decode($_GET['usuario']));
        if ($user->verificarLogin()) {
            $_SESSION["user"] = "true";
            header('Location: /MFA.php');
        } else {
            throw new InvalidArgumentException('Eh aqui no debe de haber hackers.');
        }
    }
    catch (Exception $e)
    {
        $notification->type = 'danger';
        $notification->text = $e->getMessage();
    }
}
//Solo arregalmos los datos para mandarlos al GET
if (!empty($_POST))
{
    $objectPost=(object)$_POST;
    $loginAttempt = serialize($objectPost);
    header('Location: /?usuario=' . base64_encode($loginAttempt));
    die();
}

include 'template/login.html';
