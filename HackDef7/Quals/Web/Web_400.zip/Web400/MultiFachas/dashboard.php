<?php
$flag = getenv('flag');
session_start();

if(!isset($_SESSION)){
    header('Location: /');
}
if(!isset($_SESSION["user"])){
    header('Location: /');
}
if($_SESSION["user"]!=="true"){
    header('Location: /');
}
if(!isset($_SESSION["mfa"])){
    header('Location: /');
}
if($_SESSION["mfa"]!=="true"){
    header('Location: /');
}


include 'template/dashboard.html';


