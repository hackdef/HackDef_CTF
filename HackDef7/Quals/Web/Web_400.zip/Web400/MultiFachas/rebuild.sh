#This script will deleta all data and rebuld the doker images

sudo docker stop php-app
sudo docker rm php-app
sudo docker stop php-nginx
sudo docker rm php-nginx
sudo docker stop mysql-db
sudo docker rm mysql-db
sudo docker-compose up -d --no-deps --build
