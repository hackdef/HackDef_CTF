<?php
include 'class/Token.php';
session_start();

//Validamos la sesion
if(!isset($_SESSION)){
    header('Location: /');
}
if(!isset($_SESSION["user"])){
    header('Location: /');
}
if($_SESSION["user"]!=="true"){
    header('Location: /');
}


$notification = "";

if (!empty($_GET) && isset($_GET['token'])) {
    $notification = new stdClass();
    try
    {
        $token = new Token(base64_decode($_GET['token']));
        if ($token->verificarMFA()) {
            $_SESSION["mfa"] = "true";
            header('Location: /dashboard.php');
        } else {
            throw new InvalidArgumentException('Eh aqui no debe de haber hackers.');
        }
    }
    catch (Exception $e)
    {
        $notification->type = 'danger';
        $notification->text = $e->getMessage();
    }
}


if (!empty($_POST))
{
    $objectPost=(object)$_POST;
    $loginAttempt = serialize($objectPost);
    header('Location: /MFA.php?token=' . base64_encode($loginAttempt));
    die();
}

include 'template/mfa.html';

