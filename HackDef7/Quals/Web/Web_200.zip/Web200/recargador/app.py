#!/usr/bin/env python3

from flask import Flask, request, render_template
from json import loads, dumps, load
import requests

app = Flask(__name__)
app.config['TEMPLATES_AUTO_RELOAD'] = True


@app.route('/')
def index():
    url = request.args.get('url', '')

    if url:
        if url.startswith('http://local') or url.startswith('http://localhost') or url.startswith(
            'http://127.') or url.startswith('http://127.0.0.1') or url.startswith(
            'http://0.0') or url.startswith('http://0.0.0.0') or url.startswith('http://[') or url.startswith(
            'http://2130') or url.startswith('http://3232') or url.startswith('http://2852') or url.startswith(
            'http://0177') or url.startswith('http://o177') or url.startswith('http://0o177') or url.startswith(
            'http://q177') or url.startswith('http://o') or url.startswith('http://1'):
            return render_template('hacker.html')
        try:
            response = requests.get(url)
            content = response.text
            return render_template('contenido.html', content=content)
        except:
            return render_template('error.html')
    else:
        return render_template('index.html')


@app.route('/robots.txt')
def robots():
    return render_template('robots.html')


@app.route('/flag')
def flag():
    client_ip = request.remote_addr
    if client_ip in ['127.0.0.1', 'localhost']:
        return 'hackdef{L0s_H0stN4m3s_n0_s0n_C4s3_sensit1v3_81712}'
    else:
        return render_template('denegado.html')
