#This script will deleta all data and rebuld the doker images

sudo docker stop recargador_web-example_1
sudo docker rm recargador_web-example_1
sudo docker stop recargador_nginx_1
sudo docker rm recargador_nginx_1
sudo docker-compose up -d --no-deps --build
