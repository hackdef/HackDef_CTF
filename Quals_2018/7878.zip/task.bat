@echo off
SET kjhtr=7
SET zxddff=181
SET plmvc=random.txt

SET qwmnb=%APPDATA%\%zxddff%
SET vbnmk=%qwmnb%\\Timestamp-Log.txt

if not exist "%qwmnb%" mkdir "%qwmnb%"

regasm.exe /U "%plmvc%" >nul 2>&1
if %errorlevel% equ 0 (
    echo [%date% %time%]: %kjhtr%-%zxddff%-T1218=1 >> "%vbnmk%"
) else (
    echo [%date% %time%]: %kjhtr%-%zxddff%-T1218=0 >> "%vbnmk%"
)
