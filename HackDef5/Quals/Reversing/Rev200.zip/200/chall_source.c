#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

int check_flag(char *flag);

int main(int argc, char *argv[]){
    int x;
    if( argc == 2 ) {
    //   printf("El argumento es %s\n", argv[1]);
        x = check_flag(argv[1]);
        // printf("%d\n", x);
        if(x == 0){
            printf("Sorry =(, intenta de nuevo\n");
            return 0;
      }

    //   printf("Eso, limpio!");

   }
   else if( argc > 2 ) {
      printf("Solo un argumento es permitido\n");
   }
   else {
      printf("Un argumento necesiario.\n");
   }

    printf("Eso, limpio!\n");
    return 0;
}

int check_flag(char *flag){
    size_t len = strlen(flag);
    
    if(len != 0x1c){
        return 0;
    }

    if((int)flag[12] == 95  && (int)flag[16] == 95 && (int)flag[20] == 95 && (int)flag[24] == 95){
        if((int)flag[0x09] == 0x31 && (int)flag[0x0D] == 0x31 && (int)flag[0x0F] == 0x31 && (int)flag[0x16] == 0x31){
            if((int)flag[0x08] ^ 0x4D == 0 && (int)flag[19] ^ 117 == 0){
                if(((int)flag[0x15] + (int)flag[0x17]) / 2 == 100){
                    if(flag[10] == 'P' && flag[17] == 'y' && flag[26] == 't'){
                        char temp[3] = {flag[11] , flag[14], flag[18]};
                        if(atoi(temp) == 500){
                            // printf("%s\n", temp);
                            if((int) toupper(flag[25]) == 73){
                                return 1;
                            }else{
                                return 0;
                            }

                        }else{
                            return 0;
                        }

                    }else{
                        return 0;
                    }

                }else{
                    return 0;
                }

            }else{
                return 0;
            }
            
        }else{
            return 0;
        }

    }else{
        return 0;
    }
    // printf("%zu\n",len);


    return 0;
}