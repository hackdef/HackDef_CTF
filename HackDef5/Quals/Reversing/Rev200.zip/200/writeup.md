# Chall 200 hackDef quals wirteup

El reto consiste en analizar una funcion de un ejecutable MIPS de 32bits, la funcion es realmente sencilla

A la funcion se le pasa la flag y esta tiene que cumplir una serie de condiciones anidadas para que valide toda la flag

Empezamos con el largo de la flag que es 0x1C o 28 decimial.

Posteriormente la logica comenzara a evaluar el contenido de la flag (lo que va entre llaves)

Los caracteres 12,16,20,24 deben sen iguales a "_"

Los caracteres 9,13,15,22 son numeros 1

El caracter 8 y 19 son M y t respectivamente

El resultado de la suma del caracter 21 y 23 dividido entre 2 debe ser igual a 100, lo que nos da 2 letras "d"

Los caracteres 10,17,26 son letras que vienen en texto plano en el desensamblado

Los caracteres 11,14,18 se concatenan y llamando a la funcion atoi se convierten en un numero que es igual a 500

El caracter 25 se convierte a mayuscula y se compara con 0x49 que es I lo que nos indica que en la flag debe ser "i"

Dando como resultado la flag, en este caso no es necesario implementar ningun script, simplemente con analisis estatico de las posiciones de la flag se obtiene la misma

El archivo check_flag_ida.mips me parece el mas indicado para el reto, ya que son las instrucciones en asm que genera el IDA cuando se desensambla el binario

Hackdef{M1P5_101_y0u_d1d_it}
