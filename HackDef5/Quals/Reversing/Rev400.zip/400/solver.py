from z3 import *

flag = [BitVec('val_%i'%i, 32) for i in range(0,46)]

s = Solver()

s.add(flag[0] == ord('H'))
s.add(flag[1] == ord('a'))
s.add(flag[2] == ord('c'))
s.add(flag[3] == ord('k'))
s.add(flag[4] == ord('d'))
s.add(flag[5] == ord('e'))
s.add(flag[6] == ord('f'))
s.add(flag[7] == ord('{'))
s.add(flag[45] == ord('}'))

for i in range(8,45):
    s.add(flag[i] > 0x20, flag[i] < 0x7E)


#check_9
s.add(flag[2] > 0x60, flag[2] < 0x7B)
s.add(flag[21] > 0x60, flag[21] < 0x7B)
s.add(flag[33] > 0x60, flag[33] < 0x7B)
s.add(flag[34] > 0x60, flag[34] < 0x7B)


#check_8
s.add(flag[13] > 0x29, flag[13] < 0x3A)
s.add(flag[17] > 0x29, flag[17] < 0x3A)
s.add(flag[19] > 0x29, flag[19] < 0x3A)
s.add(flag[23] > 0x29, flag[23] < 0x3A)

#check_A
s.add(flag[14] > 0x40, flag[14] < 0x5B)
s.add(flag[31] > 0x40, flag[31] < 0x5B)

#check_f
s.add(flag[33] * flag[35] == 8100)
s.add(flag [36] * flag[32] == 4845)
s.add(flag[9] + flag [29] + flag[41] + flag[13] == 192)

#check_e
s.add(flag[26] - flag[44] == 40)
s.add(flag[39] - flag[28] == 28)
s.add(flag[26] - flag[40] == 7)

#check_d
s.add(flag[17] + flag[14] + flag[12] + flag[16] + flag[13] + flag[15] + flag[18] == 562)

#check_c
s.add(((flag[14] + flag[19] + flag[8]) * flag[38]) == 12532)
s.add(flag[8] ^ flag[38] ^ flag[23] ^ flag[29] == 64)


#check_B
s.add(flag[41] * flag[9] * flag[8] * flag[42] == 22756608)
s.add(flag[21] * flag[22] * flag[23] * flag[24] == 63419112)

#check_6
s.add(flag[11] == flag[20], flag[11] == flag[25], flag[11] == flag[32], flag[11] == flag[37])
s.add(flag[11] + flag[20] + flag[25] + flag[32] + flag[37] + flag[39] == 0x474 / 2)


#check_2
s.add(((flag[2] * 2) + (flag[15] * flag[15]) + (flag[30] ^ 7)) + (flag[8] + 0x604 +  (flag[19] * 0x59) + (flag[33] * 0x08) + (flag[15] / 2)) == 0x4F9C)

#check_5
s.add(((flag[4] * flag[12] * flag[24]) + flag[34]) + ((flag[5] * flag[4] * flag[34]) + (flag[16] * flag[31]) + flag[34]) == 0x2306CA)

#check_7
s.add(flag[27] ^ flag[0] == 0x04)
s.add((0x04 + flag[21]) * (flag[17] + flag[13]) * (flag[7] - 0x04) == 0x148A50)

#check_3
s.add((flag[23] ^ flag[35] ^ flag[3]) | flag[14] == flag[10])
s.add(((flag[29] & flag[38] & flag[10]) | flag[14]) + 0x14 == flag[3])
s.add((flag[23] ^ flag[35] ^ flag[3]) | flag[14] == 87)

#check_1
s.add((flag[9] + flag[36] + flag[26] + flag[28] + 61) / (flag[22] + flag[1] + flag[6]) == 1)

#check_4
s.add(flag[45] - flag[43] == 0xA)
s.add(flag[44] + flag[40] == 0x63)
s.add(flag[18] + flag[45] + flag[43] == 0x164)
s.add(flag[44] + flag[40] + flag[18] + flag[45] + flag[43] + flag[41] + flag[42] == 0x24A)

# print(s.model())
if(s.check() == sat):
    m = s.model()
    fFlag = ""
    # print(m)
    for i in range(46):
        fFlag += chr(m[flag[i]].as_long())
    print(fFlag)
else:
    print("Sorry ... :(")

