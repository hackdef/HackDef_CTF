using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zilc0d3
{
    class Program
    {
        static void Main(string[] args)
        {
            String secret;
            Console.WriteLine("Zilc0d3\nSeguro que entendiste el ILCODE?\nEchame la flag crack...");
            secret = Console.ReadLine();
            CheckFlag(secret);
            Console.ReadLine();
        }


        public static void CheckFlag(String flag)
        {
            byte[] fbytes = Encoding.ASCII.GetBytes(flag);

            if (fbytes.Length == 0x2e)
            {
                int const_H = Check_6(fbytes[11], fbytes[20], fbytes[25], fbytes[32], fbytes[37], fbytes[39]);
                if (Convert.ToBoolean(const_H))
                {
                    int const_a = Check_D(fbytes[2], fbytes[8], fbytes[15], fbytes[19], fbytes[30], fbytes[33]);
                    if (Convert.ToBoolean(const_a))
                    {
                        int const_c = Check_5(fbytes[4], fbytes[5], fbytes[12], fbytes[16], fbytes[24], fbytes[31], fbytes[34]);
                        if (Convert.ToBoolean(const_c))
                        {
                            int const_k = Check_7(fbytes[27], fbytes[21], fbytes[17], fbytes[13], fbytes[7], fbytes[0]);
                            if (Convert.ToBoolean(const_k) && Check_8(fbytes[17]) && Check_9(fbytes[21]) && Check_8(fbytes[13]))
                            {
                                int const_d = Check_3(fbytes[23], fbytes[29], fbytes[35], fbytes[38], fbytes[3], fbytes[10], fbytes[14]);
                                if (Convert.ToBoolean(const_d) && Check_A(fbytes[14]) && Check_8(fbytes[23]))
                                {
                                    int const_e = Check_1(fbytes[9], fbytes[36], fbytes[22], fbytes[1], fbytes[26], fbytes[6], fbytes[28]);
                                    if (Convert.ToBoolean(const_e))
                                    {
                                        int const_f = Check_4(fbytes[44], fbytes[40], fbytes[18], fbytes[45], fbytes[43], fbytes[41], fbytes[42]);
                                        if (Convert.ToBoolean(const_f))
                                        {
                                            int const_n = Check_B(fbytes[41], fbytes[9], fbytes[8], fbytes[42], fbytes[21], fbytes[22], fbytes[23], fbytes[24]);
                                            int const_o = Check_F(fbytes[8], fbytes[38], fbytes[23], fbytes[29], fbytes[14], fbytes[19], fbytes[8]);
                                            if (Convert.ToBoolean(const_n) && Convert.ToBoolean(const_o))
                                            {
                                                int const_t = Check_2(fbytes[17], fbytes[14], fbytes[12], fbytes[16], fbytes[13], fbytes[15], fbytes[18]);
                                                bool const_m = Check_E(fbytes[26], fbytes[39], fbytes[26], fbytes[40], fbytes[28], fbytes[44]);
                                                bool const_4 = Check_C(fbytes[33], fbytes[36], fbytes[35], fbytes[32], fbytes[9], fbytes[29], fbytes[41], fbytes[13]);
                                                if (Convert.ToBoolean(const_t) && const_m && const_4)
                                                {
                                                    Console.WriteLine("Vaya, sabes leer!\nNice!");
                                                }
                                                else
                                                {
                                                    Environment.Exit(0);
                                                }
                                            }
                                            else
                                            {
                                                Environment.Exit(0);
                                            }

                                        }
                                        else
                                        {
                                            Environment.Exit(0);
                                        }
                                    }
                                    else
                                    {
                                        Environment.Exit(0);
                                    }

                                }
                                else
                                {
                                    Environment.Exit(0);
                                }

                            }
                            else
                            {
                                Environment.Exit(0);
                            }

                        }
                        else
                        {
                            Environment.Exit(0);
                        }
                    }
                    else
                    {
                        Environment.Exit(0);
                    }
                }
                else
                {
                    Environment.Exit(0);
                }
            }
            else
            {
                Environment.Exit(0);
            }
        }

        private static int Check_6(byte a, byte b, byte c, byte d, byte e, byte f)
        {
            int x;
            x = a + b + c + d + e + f;
            if (x == 0x474 / 2 && a == b & a == c & a == d && a == e)
            {
                return 1;
            }
            return 0;
        }

        private static int Check_D(byte a, byte b, byte c, byte d, byte e, byte f)
        {
            int x, y;
            x = (a * 2) + (c * c) + (e ^ 7);
            y = b + 0x604 + (d * 0x59) + (f * 0x08) + (c / 0x02);
            if (x + y == 0x4F9C && Check_9(a) && Check_8(d) && Check_9(f))
            {
                return 1;
            }
            return 0;
        }

        private static int Check_5(byte a, byte b, byte c, byte d, byte e, byte f, byte g)
        {
            if (Check_A(f) && Check_9(g))
            {
                int x, y;
                x = (a * c * e) + g;
                y = (b * a * g) + (d * f) + g;

                if (x + y == 0x2306CA)
                {
                    return 1;
                }
            }

            return 0;
        }

        private static int Check_7(byte a, byte b, byte c, byte d, byte e, byte f)
        {
            int x, y;
            x = a ^ f;
            y = (x + b) * (c + d) * (e - x);

            if (y == 0x148A50 && x == 0x04)
            {
                return 1;
            }

            return 0;
        }

        private static int Check_3(byte a, byte b, byte c, byte d, byte e, byte f, byte g)
        {
            int x, y;
            x = (a ^ c ^ e) | g;
            y = (b & d & f) | g;
            if (x == f)
            {
                if (y + 0x14 == e)
                {
                    if (x == y)
                    {
                        return 1;
                    }

                }
            }
            return 0;
        }

        private static int Check_1(byte a, byte b, byte c, byte d, byte e, byte f, byte g)
        {
            int x, y;
            x = a + e + g + 61 + b;
            y = c + d + f;
            if (Convert.ToBoolean(x / y))
            {
                return x / y;
            }
            return 0;
        }

        private static int Check_4(byte a, byte b, byte c, byte d, byte e, byte f, byte g)
        {
            int x;
            if (d - e == 0xA)
            {
                if (a + b == 0x63)
                {
                    if (c + d + e == 0x164)
                    {
                        x = a + b + c + d + e + f + g;
                        if (x == 0x24A)
                        {
                            return 1;
                        }
                    }
                }
            }

            return 0;
        }

        private static bool Check_8(byte a)
        {
            if (a > 0x29 && a < 0x3A)
            {
                return true;
            }
            return false;
        }

        private static bool Check_9(byte a)
        {
            if (a > 0x60 && a < 0x7B)
            {
                return true;

            }
            return false;
        }

        private static bool Check_A(byte a)
        {
            if (a > 0x40 && a < 0x5B)
            {
                return true;
            }
            return false;
        }

        private static int Check_B(byte a, byte b, byte c, byte d, byte e, byte f, byte g, byte h)
        {
            int x, y;
            x = a * c * b * d;
            y = h * e * g * f;
            if (x == 0x15B3D00 && y == 0x3C7B2E8)
            {
                return 1;
            }
            return 0;
        }

        private static int Check_F(byte a, byte b, byte c, byte d, byte e, byte f, byte g)
        {
            int x, y;
            x = (e + f + g) * b;
            y = a ^ b ^ c ^ d;
            if (x == 0x30F4 && y == 0x40)
            {
                return 1;
            }
            return 0;
        }

        private static int Check_2(byte a, byte b, byte c, byte d, byte e, byte f, byte g)
        {
            int x;
            x = a + b + c + d + e + f + g;
            if (x == 0x232)
            {
                return 1;
            }
            return 0;
        }

        private static bool Check_E(byte a, byte b, byte c, byte d, byte e, byte f)
        {
            int x, y, z;
            x = a - f;
            y = b - e;
            z = c - d;
            if (x == 0x28 && y == 0x1C && z == 0x07)
            {
                return true;
            }
            return false;
        }

        private static bool Check_C(byte a, byte b, byte c, byte d, byte e, byte f, byte g, byte h)
        {
            int x, y, z;
            x = a * c;
            y = b * d;
            z = h + g + f + e;
            if (x == 8100 && y == 4845 && z == 192)
            {
                return true;
            }
            return false;
        }

    }
}
