# Zilc0d3 reto 400 pts

El reto consiste en un console app en C# .Net Framework version 4.7.2, una funcion main que manda a llamar a la funcion CheckFlag y esta a su vez cuenta con 15 funciones validadoras para ciertos indices de la flag, este reto debe salir con Z3 theorem solver, ya que cada una de las funciones cuenta con constrains que deben cumplirse para dar con la flag correcta.

El reto combina analisis estatico de lenguaje C# e ILCODE, teniendo en cuenta que tuvimos un reto mas sencillo de ILCODE analisys

Una vez que se compilo el binario se decompilo con ildasm para borrar la linea ldarg.o de las sigueintes funciones

* check_e
* Check_C
* Check_2
* Check_4
* Check_D
* Check_8
* Check_9
* Check_A
* Check_F
* CheckFlag

Posteriormente se compilo nuevamente con ilasm

Esto con el fin de que una vez que se decompile el binario con ILSpy o DnSpy, no pueda recuperarse el codigo original de dichas funciones, lo que obligara al participante a analizar el ilcode de dichas funciones para obtener los constrians de las mismas y poder hacer el script correspondiente o en su defecto investigar el porque estas funciones no se muestran correctamente y realizar el parchado del binario, lo que restaurara la funcionalidad y podra recuperar el codigo C# de estas funciones.

La complejidad de dichas funciones es variable, algunas solo cuentan con algun if, menor y mayor que, hasta ciertas operaciones como sumas, restas, multiplicaciones y operaciones como XOR, AND y OR, entre los caracteres de la flag.

Incluso si el participante logra obtener el codigo de todas las funciones dañadas debe analizarlas y obtener los contrains que deberan meter a un solver con Z3 para que este les arroje la flag correcta

Lo cual no es muy dificil ya que cuentan con el formato de flag, siendo un total de 37 caracteres que deben calcular mediante las validaciones que se les da en el binario, siendo un total de 36 constrains que deben resolver, lo que lo complica un poco para calcular de manera artesanal o brute force

El script en Z3 que resuelve el binario se encuentra en los recursos del reto como solver.py
El codigo original del reto esta en los recursos del reto como code.cs

Si el reto se complica podemos dar las siguientes pistas

ldarg.0 -> que investiguen que es
metodos antidecompilacion para .Net
o ya de plano el PDF -> [.Net for hackers by S4tan](https://es.slideshare.net/s4tan/net-for-hackers)
ya si de plano nada podemos dar el binario sin obfuscar, de esta manera tendran todas las funciones bien decompiladas

Se muestra en figura1 la funcion correctamente decompilada y figura2 como se ve la funcion con el antidebugging trick