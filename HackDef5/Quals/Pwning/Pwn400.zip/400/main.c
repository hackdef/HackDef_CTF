#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <unistd.h>

#define TAM_DATOS 0x10

const int ARR = 0;
const int LISTA = 1;

struct l_elem{
    union {
        struct l_elem* sig;
        uint64_t cant;
    };
    char datos[TAM_DATOS];
    uint8_t tipo;
} __attribute__((packed));

struct l_elem* mi_lista;

struct l_elem arr[0x10];
int cant;

uint64_t DEBUG = 0;

int lee_idx(){
    printf("idx :\n> ");
    int idx = -1;
    scanf("%d", &idx);
    if(idx >= cant) idx = -1;
    if(idx < 0){
        puts("idx invalido");
        exit(1);
    }
    return idx;
}

void crear_elemento(){
    if(cant >= 0x10){
        puts("No hay mas espacio");
        exit(1);
    }
    printf("Ingresa el nombre de este elemento:\n> ");

    read(0, arr[cant].datos, TAM_DATOS);

    printf("Ingresa la cantidad:\n> ");
    scanf("%ld", &arr[cant].cant);

    printf("Elemento agregado en el idx : %d\n", cant);
    arr[cant].tipo = ARR;

    cant++;
}

void agregar_elemento(){
    int idx = lee_idx();

    if(&arr[idx] == mi_lista){
        puts("No puedes agregar el mismo producto");
        exit(1);
    }

    if(arr[idx].tipo == LISTA){
        puts("Este elemento ya esta en lista");
    }

    printf("Agregando %s\n", arr[idx].datos);

    arr[idx].sig = mi_lista;
    mi_lista = &arr[idx];
    mi_lista->tipo = LISTA;
}

void mostrar_lista(){
    puts("[*] LISTA DE COMPRAS [*]");
    struct l_elem* act = mi_lista;
    int i = 0;
    while(act != NULL){
        printf("%d. %s\n", i, act->datos);
        i++;
        act = act->sig;
    }
}

void mostrar_alacena(){
    puts("[*] ALACENA [*]");
    for(int i = 0; i < cant; i++){
        printf("%d. %s\t-\t", i, arr[i].datos);
        if(arr[i].tipo == LISTA){
            puts("PRODUCTO AGOTADO");
        }else{
            printf("%ld\n", arr[i].cant);
        }
    }
}

void comprar_elemento(){
    if(mi_lista == NULL){
        puts("La lista de compras esta vacia");
        exit(1);
    }
    printf("Comprando\t%s\n", mi_lista->datos);
    uint64_t pz = 0;
    printf("pz :\n> ");
    scanf("%ld", &pz);
    struct l_elem* act = mi_lista;
    mi_lista = mi_lista->sig;
    act->cant = pz;
    act->tipo = ARR;
}

void entrar_shell(){
    if(DEBUG != 0xbebedef){
        puts("Alto ahi hacker");
    }else{
        puts("Pasale jefe");
        system("/bin/sh");
    }
}

int menu(){
    puts("[*] Menu");
    puts("[*] 1. Agregar elemento a alacena");
    puts("[*] 2. Agregar elemento a mi lista");
    puts("[*] 3. Mostrar alacena");
    puts("[*] 4. Mostrar mi lista");
    puts("[*] 5. Comprar elemento");
    puts("[*] 6. Salir");

    printf("> ");
    int op = -1;
    scanf("%d", &op);
    return op;
}

void init_buffers(){
    setbuf(stdin, NULL);
    setbuf(stdout, NULL);
    setbuf(stderr, NULL);
}

int main(){
    init_buffers();

    int op;
    while((op = menu()) != 6){
        switch(op){
            case 1:
                crear_elemento();
                break;
            case 2:
                agregar_elemento();
                break;
            case 3:
                mostrar_alacena();
                break;
            case 4:
                mostrar_lista();
                break;
            case 5:
                comprar_elemento();
                break;
            case 6:
                puts("Adios :)");
                break;
            case 1337:
                puts("...");
                entrar_shell();
                break;
            default:
                puts("Opcion invalida");
                break;
        }
    }
    return 0;
}

