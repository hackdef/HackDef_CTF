#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char str[] = "eweorak";

void f1(){
	puts("F1");
	strncat(str, "/", 1);
}

void f2(){
	puts("F2");
	strncat(str, "s", 1);
}

void f3(){
	puts("F3");
	strncat(str, "bin", 3);
}

void f4(){
	puts("F4");
	strncat(str, "h", 1);
}

void f5(){
	puts(str);
	system(str);
}

void f6(){
	puts("F6");
	strcpy(str, "/");
}

int p0(){
	char x[2500];
	char var[] = "";
	puts("Cuando el peligro se acerca, no soy nada lenta. Porque brinco, brinco, brinco y alla voy yo");
	gets(var);
	return 0;
}

int main(){
	p0();
	puts(" .----------------."); 
	puts("| .--------------. |");
	puts("| |  _________   | |");
	puts("| | |_   ___  |  | |");
	puts("| |   | |_  \\_|  | |");
	puts("| |   |  _|      | |");
	puts("| |  _| |_       | |");
	puts("| | |_____|      | |");
	puts("| |              | |");
	puts("| '--------------' |");
	puts(" '----------------'");
}
