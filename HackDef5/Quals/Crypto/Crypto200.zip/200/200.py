#!/usr/bin/env python3
import socketserver
import hashlib
import random
import string
from Bandera import bandera


class Handler(socketserver.BaseRequestHandler):
    def handle(self):
        prefix = "".join(random.choice(string.digits+string.ascii_letters) for i in range(10))
        self.request.sendall("Bienvenido al segundo reto, te recomiendo usar pwntools\n".encode('utf8'))
        self.request.sendall("Mandame una cadena que comience con {} de longitud {} tal que su hash de longitud de 40 caracteres termine en ffffff\n".format(prefix, len(prefix)+6).encode('utf8'))
        self.request.sendall("Solo tienes un intento.\n".encode('utf8'))
        l = self.request.recv(len(prefix)+6+1).strip()
        if len(l) != len(prefix)+6 or not l.startswith(prefix.encode('utf8')) or hashlib.sha1(l).hexdigest()[-6:] != "ffffff":
            self.request.sendall(b"La bandera es ...... vuelve a intentar.\n")
            return
        else:
        	self.request.sendall("Bien hecho, la bandera es {}\n".format(bandera).encode('utf-8'))

class ThreadingTCPServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    pass

if __name__ == "__main__":
    HOST, PORT = "127.0.0.1", 10701
    socketserver.ThreadingTCPServer.allow_reuse_address = True
    server = socketserver.ThreadingTCPServer((HOST, PORT), Handler)
    server.serve_forever()