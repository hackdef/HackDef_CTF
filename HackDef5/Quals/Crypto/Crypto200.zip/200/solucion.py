#!/usr/bin/env python3
from pwn import *
import itertools
import string

conn = remote('127.0.0.1',10701)
conn.recvline()
cadena_1 = conn.recvline()
conn.recvline()
texto = cadena_1.split()[6]
for z in itertools.product(string.digits+string.ascii_letters, repeat = 6):
	ntexto= texto + "".join(z).encode()
	if hashlib.sha1(ntexto).hexdigest()[-6:] == "ffffff":
		conn.send(ntexto+b'\n')
		print("Se mando {}".format(ntexto))
		bandera = conn.recvline()
		print(bandera)
		conn.close()
		break
	else:
		continue