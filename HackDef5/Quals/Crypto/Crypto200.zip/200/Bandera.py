bandera = 'Hackdef{SHA1_ya_no_es_tan_seguro_como_dicen}'
