<html>
 <head>
  <link rel="stylesheet" href="styles.css">
 </head>
	<h1>¡Bienvenid@ a mi galería!</h1>
	<h3>Disfruta mi colección de imágenes</h3><br/>
	<form action="download.php" method="POST">
		<center>
		<table border="1px solid">
			<tr style="background:black;color:white">
				<td>Imagen
				</td>
				<td>Seleccionar
				</td>

			</tr>
			<tr>
				<td><img src="images/image_1.jpeg" height="200px" width="auto"/></td>
				<td><input type="radio" name="image_path" value="TzoxNDoiRG93bmxvYWRfSW1hZ2UiOjI6e3M6NDoicGF0aCI7czoyODoiYVcxaFoyVnpMMmx0WVdkbFh6RXVhbkJsWnc9PSI7czo5OiJvcGVyYXRpb24iO3M6ODoiRG93bmxvYWQiO30" required/></td>
			</tr>
			<tr>
				<td><img src="images/image_2.jpeg" height="200px" width="auto"/></td>
				<td><input type="radio" name="image_path" value="TzoxNDoiRG93bmxvYWRfSW1hZ2UiOjI6e3M6NDoicGF0aCI7czoyODoiYVcxaFoyVnpMMmx0WVdkbFh6SXVhbkJsWnc9PSI7czo5OiJvcGVyYXRpb24iO3M6ODoiRG93bmxvYWQiO30=" required/></td>
			</tr>
			<tr>
				<td><img src="images/image_3.jpeg" height="200px" width="auto"/></td>
				<td><input type="radio" name="image_path" value="TzoxNDoiRG93bmxvYWRfSW1hZ2UiOjI6e3M6NDoicGF0aCI7czoyODoiYVcxaFoyVnpMMmx0WVdkbFh6TXVhbkJsWnc9PSI7czo5OiJvcGVyYXRpb24iO3M6ODoiRG93bmxvYWQiO30=" required/></td>
			</tr>
			<tr>
				<td><img src="images/image_4.jpeg" height="200px" width="auto"/></td>
				<td><input type="radio" name="image_path" value="TzoxNDoiRG93bmxvYWRfSW1hZ2UiOjI6e3M6NDoicGF0aCI7czoyODoiYVcxaFoyVnpMMmx0WVdkbFh6UXVhbkJsWnc9PSI7czo5OiJvcGVyYXRpb24iO3M6ODoiRG93bmxvYWQiO30=" required/></td>
			</tr>
			<tr>
				<td><img src="images/image_5.jpeg" height="200px" width="auto"/></td>
				<td><input type="radio" name="image_path" value="TzoxNDoiRG93bmxvYWRfSW1hZ2UiOjI6e3M6NDoicGF0aCI7czoyODoiYVcxaFoyVnpMMmx0WVdkbFh6VXVhbkJsWnc9PSI7czo5OiJvcGVyYXRpb24iO3M6ODoiRG93bmxvYWQiO30=" required/></td>
			</tr>
			<tr><td><center><button>Descargar</button></center></td></tr>
		</table>
	</center>
	</form>
</html>