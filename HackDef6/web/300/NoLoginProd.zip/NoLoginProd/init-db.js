db.createCollection('users')
user_admin = {'username':'admin','password':'Is_D4nGer0us-T0_60-al0n3-t4k3-th1s!!!'}

db.users.insertOne(user_admin)
